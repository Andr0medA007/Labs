﻿#include <iostream>
using namespace std;

static int fibonacci(unsigned int n){
    if (n == 1 || n == 2)
        return 1;
    if (n == 0)
        return 0;
    return fibonacci(n - 1) + fibonacci(n - 2);
}
int main()
{
    setlocale(LC_ALL, "Ru");
    int n;
    cout << "Введите длину ряда фибоначчи: " << endl;
    cin >> n;

    for (int i = 1; i <= n; i++)
    {
        cout << i << ": " << fibonacci(i-1) << endl;
    }

    return 0;
}


