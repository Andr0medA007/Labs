﻿#include <iostream>
#include <string>
#include <cmath>

using namespace std;
int main()
{
	setlocale(LC_ALL, "Ru");
	system("chcp 1251"); // изменение кодовой страницы на 1251, популярную в странах СНГ
	system("cls");
	string str;
	int k = 0;
	str = "HELO_WORLD!";
	int m = str.size();
	for (int y = 0; y < m; y++) {
		for (int x = 0; x < m; x++) {
			if (y == (m-x-1)) {
				cout << str[m-x-1];
			}
			else {
				cout << " ";
			}

		}
		cout << endl;
	}
	
}